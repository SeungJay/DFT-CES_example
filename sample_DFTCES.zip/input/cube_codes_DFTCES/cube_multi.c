#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct{
 double cell[3];
 int nAtoms;
 int nGrid[3];
 int* atomN;
 double* atomX;
 double* atomY;
 double* atomZ;
 double* grid;
}cube;

void saveCube(cube input, char* fname);

main(int argc, char *argv[]){
 char potFile[200];
 double multiplier;
 //arguments parsing
 if(argc==3){
  sprintf(potFile,"%s",argv[1]);
  if(access(potFile,F_OK) == -1){
   printf("File does not exist.\n");
   return 0;
  }
  multiplier = atof(argv[2]);
 }
 else{
  printf("Usage: ./cube_multi cubefile multiplier\n");
  return 0;
 }

 cube base;

 FILE* fp;
 char str[2048], *str_ptr;
 int flag=0, nline=0,cnt=0,nAtoms=0;
 int i, j, k;

 fp=fopen(potFile, "r");
 base.nAtoms=0;
 base.cell[0]=base.cell[1]=base.cell[2]=(double)0; 
 
 while(fgets(str,sizeof(str),fp)!=NULL){
  nline++;
 
  if(nline==3){
   sscanf(str,"%d %*f %*f %*f",&base.nAtoms);
   base.atomN = (int *) malloc (base.nAtoms*sizeof(int));
   base.atomX = (double *) malloc (base.nAtoms*sizeof(double));
   base.atomY = (double *) malloc (base.nAtoms*sizeof(double));
   base.atomZ = (double *) malloc (base.nAtoms*sizeof(double));
  }
   
  if(nline==4){
   sscanf(str,"%d %lf %*f %*f",&base.nGrid[0], &base.cell[0]);
   base.cell[0]=base.nGrid[0]*base.cell[0];
  }
  
  if(nline==5){
   sscanf(str,"%d %*f %lf %*f",&base.nGrid[1], &base.cell[1]);
   base.cell[1]=base.nGrid[1]*base.cell[1];
  }
  
  if(nline==6){
   sscanf(str,"%d %*f %*f %lf",&base.nGrid[2], &base.cell[2]);
   base.cell[2]=base.nGrid[2]*base.cell[2];
  }
  
  if(nline>=7 && nline<7+base.nAtoms){
    sscanf(str,"%d %*f %lf %lf %lf",&base.atomN[nline-7],&base.atomX[nline-7],&base.atomY[nline-7],&base.atomZ[nline-7]);
  }
  
  if(nline==base.nAtoms+6){
   printf("### Cell parameters(Bohr): %f %f %f\n", base.cell[0], base.cell[1], base.cell[2]);
   printf("### Number of Atoms: %d\n", base.nAtoms);
   printf("### Grid Dimension: %d %d %d\n", base.nGrid[0], base.nGrid[1], base.nGrid[2]);
   base.grid=(double *)malloc(base.nGrid[0]*base.nGrid[1]*base.nGrid[2]*sizeof(double));
  }
  
  if(nline>=base.nAtoms+7 && cnt<base.nGrid[0]*base.nGrid[1]*base.nGrid[2]){
   str_ptr=strtok(str," ");
   for(;str_ptr!=NULL;cnt++){
     sscanf(str_ptr,"%lf",&base.grid[cnt]);
    str_ptr=strtok(NULL," ");
   }
  }
 
 }//while end

 for(i=0;i<base.nGrid[0]*base.nGrid[1]*base.nGrid[2];i++){
   base.grid[i] *= multiplier;
 }

 saveCube(base,"multiplied.cube");

}//main END

void saveCube(cube input, char* fname){
  FILE* fp;
  int i, j, k, cnt;
  fp = fopen(fname,"w");

  fprintf(fp," Cubefile rescaled\n");
  fprintf(fp," lattice unit Bohr\n");
  fprintf(fp,"% 5d    0.000000    0.000000    0.000000\n",input.nAtoms);
  fprintf(fp,"% 5d% 12.6lf    0.000000    0.000000\n",input.nGrid[0],input.cell[0]/input.nGrid[0]);
  fprintf(fp,"% 5d    0.000000% 12.6lf    0.000000\n",input.nGrid[1],input.cell[1]/input.nGrid[1]);
  fprintf(fp,"% 5d    0.000000    0.000000% 12.6lf\n",input.nGrid[2],input.cell[2]/input.nGrid[2]);
  for(i=0;i<input.nAtoms;i++){
    fprintf(fp,"% 5d% 12.6lf% 12.6lf% 12.6lf% 12.6lf\n",input.atomN[i],(double)input.atomN[i],input.atomX[i],input.atomY[i],input.atomZ[i]);
  }
  cnt=0;
  for(i=0;i<input.nGrid[0];i++){
    for(j=0;j<input.nGrid[1];j++){
      for(k=0;k<input.nGrid[2];k++){
         fprintf(fp,"% 13.5lE",(input.grid[k+j*input.nGrid[2]+i*input.nGrid[2]*input.nGrid[1]]));
         if(cnt%6 == 5) fprintf(fp,"\n");
         cnt++;
      }
    }
  }
  fclose(fp);
  printf("### New cubefile has been saved as %s\n",fname);
}
