#include <cmath>
#include <complex>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string.h>
#include <fftw3.h>
#define PI (4.0*atan(1.0))

typedef struct{
 double cellParams[3];
 int nAtoms;
 int pGrid[3];
 int* atomN;
 double* posX;
 double* posY;
 double* posZ;
 double* pValue;
}tag_Models;

tag_Models chgParser(char* fname);
void potAvg(tag_Models input, int dir);
void savePot(tag_Models input, char* fname);
tag_Models chg2pot(tag_Models input);
tag_Models transpose(tag_Models input, int dir);
void saveCube(tag_Models input, char* fname);

main(int argc, char *argv[]){
 int i, j, k, dir;
 char chgFile[200];
 
 //arguments parsing
 if(argc==3){
  sprintf(chgFile,"%s",argv[1]);
  if(access(chgFile,F_OK) == -1){
   printf("File does not exist.\n");
   return 0;
  }
 }
 else{
  printf("Usage: ./chg2pot chgden.cube avg_dir\n");
  return 0;
 }
 dir=atoi(argv[2]);

 tag_Models baseModel;
 tag_Models potModel;
 baseModel=chgParser(chgFile); 
 potModel=chg2pot(baseModel); 
 saveCube(potModel, "pot.cube");
 potAvg(potModel, dir);

}//main END

tag_Models chgParser(char* fname){ // charge density file parsing using atomic units
 FILE* fp;
 char str[2048], *str_ptr;
 int flag=0, nline=0,cnt=0,nAtoms=0;
 tag_Models output;

 fp=fopen(fname, "r");
 output.nAtoms=0;
 output.cellParams[0]=output.cellParams[1]=output.cellParams[2]=(double)0; 
 
 while(fgets(str,sizeof(str),fp)!=NULL){
  int i, j, *temp;
  double a,b,c;
  nline++;
  
  if(nline==3){
   sscanf(str,"%d %*f %*f %*f",&output.nAtoms);
   output.atomN = (int *) malloc (output.nAtoms*sizeof(int));
   output.posX = (double *) malloc (output.nAtoms*sizeof(double));
   output.posY = (double *) malloc (output.nAtoms*sizeof(double));
   output.posZ = (double *) malloc (output.nAtoms*sizeof(double));
  }

  if(nline==4){
   sscanf(str,"%d %lf %*f %*f",&output.pGrid[0], &output.cellParams[0]);
   output.cellParams[0]=output.pGrid[0]*output.cellParams[0];
  }

  if(nline==5){
   sscanf(str,"%d %*f %lf %*f",&output.pGrid[1], &output.cellParams[1]);
   output.cellParams[1]=output.pGrid[1]*output.cellParams[1];
  }

  if(nline==6){
   sscanf(str,"%d %*f %*f %lf",&output.pGrid[2], &output.cellParams[2]);
   output.cellParams[2]=output.pGrid[2]*output.cellParams[2];
  }

  if(nline>=7 && nline<7+output.nAtoms){
    sscanf(str,"%d %*f %lf %lf %lf",&output.atomN[nline-7],&output.posX[nline-7],&output.posY[nline-7],&output.posZ[nline-7]);
  }

  if(nline==output.nAtoms+6){
   printf("### Cell parameters(Bohr): %f %f %f\n", output.cellParams[0], output.cellParams[1], output.cellParams[2]);
   printf("### Number of Atoms: %d\n", output.nAtoms);
   printf("### Grid Dimension: %d %d %d\n", output.pGrid[0], output.pGrid[1], output.pGrid[2]);
   output.pValue=(double *)malloc(output.pGrid[0]*output.pGrid[1]*output.pGrid[2]*sizeof(double));
  }

  if(nline>=output.nAtoms+7 && cnt<output.pGrid[0]*output.pGrid[1]*output.pGrid[2]){
   str_ptr=strtok(str," ");
   for(;str_ptr!=NULL;cnt++){
     sscanf(str_ptr,"%lf",&output.pValue[cnt]);
    str_ptr=strtok(NULL," ");
   }
  }
   
 }//while end
 return output;
}

void potAvg(tag_Models input, int dir){ // save averaged potential along z-dir
 FILE* fp;
 int  i, j, k;
 char fname[512];
 double avg=0;

 if(dir==1){
   sprintf(fname,"pot.x.avg");
   fp=fopen(fname,"w");
   for(i=0;i<input.pGrid[0];i++){
     for(j=0;j<input.pGrid[1];j++){
       for(k=0;i<input.pGrid[2];k++){
          avg+=input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]];
       }
     }
    avg/=input.pGrid[1]*input.pGrid[2];
    fprintf(fp,"%lf %lf\n",i*input.cellParams[0]/input.pGrid[0],avg);
    avg=0;
   }
  fclose(fp);
 } 

 if(dir==2){
   sprintf(fname,"pot.y.avg");
   fp=fopen(fname,"w");
   for(j=0;j<input.pGrid[1];i++){
     for(i=0;i<input.pGrid[0];i++){
       for(k=0;k<input.pGrid[2];k++){
          avg+=input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]];
       }
     }
    avg/=input.pGrid[0]*input.pGrid[2];
    fprintf(fp,"%lf %lf\n",j*input.cellParams[1]/input.pGrid[1],avg);
    avg=0;
   }
  fclose(fp);
 }

 if(dir==3){
   sprintf(fname,"pot.z.avg");
   fp=fopen(fname,"w");
   for(k=0;k<input.pGrid[2];k++){
     for(i=0;i<input.pGrid[0];i++){
       for(j=0;j<input.pGrid[1];j++){
          avg+=input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]];
       }
     }
    avg/=input.pGrid[0]*input.pGrid[1];
    fprintf(fp,"%lf %lf\n",k*input.cellParams[2]/input.pGrid[2],avg);
    avg=0;
   }
  fclose(fp);
 }
 
 printf("### Averaged potential along z-dir saved: %s\n",fname);
}

void savePot(tag_Models input, char* fname){ // save superModel struct data into binary file
 FILE* fp;
 double pot[input.pGrid[0]*input.pGrid[1]*input.pGrid[2]];
 int i;
 for(i=0; i<input.pGrid[0]*input.pGrid[1]*input.pGrid[2]; i++){
  pot[i]=input.pValue[i];
 }

 fp=fopen(fname, "wb");
 fwrite(&input.cellParams, sizeof(input.cellParams[0]), 3, fp);
 fwrite(&input.nAtoms, sizeof(input.nAtoms), 1, fp);
 fwrite(&input.pGrid, sizeof(input.pGrid[0]), 3, fp);
 fwrite(&pot, sizeof(double),sizeof(pot)/sizeof(double),fp);
 fclose(fp);

 printf("Potential was saved to binary file: %s\n",fname);
}

tag_Models chg2pot(tag_Models input){ // poisson solver in atomic units
 tag_Models output;
 fftw_complex *rho_q;
 fftw_plan fft, ifft;
 int i, j, k;
 std::complex<double> h[3];

 for(i=0; i<3; i++){
  h[i].real() = input.cellParams[i]/(double)input.pGrid[i];
  h[i].imag() = 0.0;
 }

 rho_q=(fftw_complex *)fftw_malloc(sizeof(fftw_complex)*input.pGrid[0]*input.pGrid[1]*input.pGrid[2]);

 for(i=0;i<input.pGrid[0];i++){
  for(j=0;j<input.pGrid[1];j++){
   for(k=0;k<input.pGrid[2];k++){
    rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][0] = 4.0*PI*input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]];
    rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][1] = 0.0;
   }
  }
 }
 fft=fftw_plan_dft_3d(input.pGrid[0],input.pGrid[1],input.pGrid[2],rho_q,rho_q,FFTW_FORWARD,FFTW_ESTIMATE);
 fftw_execute(fft);
 fftw_destroy_plan(fft);
 std::complex<double> I(0.0, 1.0);
 std::complex<double> W1 = std::exp(2.0 * PI * I / double(input.pGrid[0]));
 std::complex<double> W2 = std::exp(2.0 * PI * I / double(input.pGrid[1]));
 std::complex<double> W3 = std::exp(2.0 * PI * I / double(input.pGrid[2]));
 std::complex<double> Wi = 1.0, Wj = 1.0, Wk = 1.0;

 for(i=0;i<input.pGrid[0];i++){
  for(j=0;j<input.pGrid[1];j++){
   for(k=0;k<input.pGrid[2];k++){
    std::complex<double> denom1 = 2.0, denom2 = 2.0, denom3 = 2.0;
    denom1 -= Wi + 1.0 / Wi;
    denom2 -= Wj + 1.0 / Wj;
    denom3 -= Wk + 1.0 / Wk;
    std::complex<double> rho_temp(rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][0],rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][1]);
    if ( i+j+k != 0 ) {
      rho_temp /= denom1 / (h[0]*h[0]) + denom2 / (h[1]*h[1]) + denom3 / (h[2]*h[2]);
      rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][0] = rho_temp.real();
      rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][1] = rho_temp.imag();
    }
    Wk *= W3;
   }
   Wj *= W2;
  }
  Wi *= W1;
 }

 ifft=fftw_plan_dft_3d(input.pGrid[0],input.pGrid[1],input.pGrid[2],rho_q,rho_q,FFTW_BACKWARD,FFTW_ESTIMATE);
 fftw_execute(ifft);
 fftw_destroy_plan(ifft);

 output.pValue = (double *)malloc(sizeof(double)*input.pGrid[0]*input.pGrid[1]*input.pGrid[2]);

 for(i=0;i<input.pGrid[0];i++){
  for(j=0;j<input.pGrid[1];j++){
   for(k=0;k<input.pGrid[2];k++){
     output.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]] = rho_q[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]][0]/input.pGrid[0]/input.pGrid[1]/input.pGrid[2];
   }
  }
 }

 output.nAtoms=input.nAtoms;
 output.cellParams[0]=input.cellParams[0];
 output.cellParams[1]=input.cellParams[1];
 output.cellParams[2]=input.cellParams[2];
 output.pGrid[0]=input.pGrid[0];
 output.pGrid[1]=input.pGrid[1];
 output.pGrid[2]=input.pGrid[2];
 output.atomN=(int *)malloc(sizeof(int)*output.nAtoms);
 output.posX=(double *)malloc(sizeof(double)*output.nAtoms);
 output.posY=(double *)malloc(sizeof(double)*output.nAtoms);
 output.posZ=(double *)malloc(sizeof(double)*output.nAtoms);

 for(i=0; i<output.nAtoms; i++){
   output.atomN[i] = input.atomN[i];
   output.posX[i] = input.posX[i];
   output.posY[i] = input.posY[i];
   output.posZ[i] = input.posZ[i];
 }

 fftw_free(rho_q);

 return output;
}

void saveCube(tag_Models input, char* fname){
  FILE* fp;
  int i, j, k, cnt;
  fp = fopen(fname,"w");

  fprintf(fp," Cubefile created from chg2pot\n");
  fprintf(fp," ES potential, lattice unit Bohr, grid unit Ha\n");
  fprintf(fp,"% 5d    0.000000    0.000000    0.000000\n",input.nAtoms);
  fprintf(fp,"% 5d% 12.6lf    0.000000    0.000000\n",input.pGrid[0],input.cellParams[0]/input.pGrid[0]);
  fprintf(fp,"% 5d    0.000000% 12.6lf    0.000000\n",input.pGrid[1],input.cellParams[1]/input.pGrid[1]);
  fprintf(fp,"% 5d    0.000000    0.000000% 12.6lf\n",input.pGrid[2],input.cellParams[2]/input.pGrid[2]);
  for(i=0;i<input.nAtoms;i++){
    fprintf(fp,"% 5d% 12.6lf% 12.6lf% 12.6lf% 12.6lf\n",input.atomN[i],(double)input.atomN[i],input.posX[i],input.posY[i],input.posZ[i]);
  }
  cnt=0;
  for(i=0;i<input.pGrid[0];i++){
    for(j=0;j<input.pGrid[1];j++){
      for(k=0;k<input.pGrid[2];k++){
         fprintf(fp,"% 13.5lE",(input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]]));
         if(cnt%6 == 5) fprintf(fp,"\n");
         cnt++;
      }
    }
  }
  fclose(fp);
  printf("### Potential was saved to %s\n",fname);
}
