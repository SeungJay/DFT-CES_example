#include <cmath>
#include <complex>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string.h>
#include <unistd.h>

typedef struct{
 double cellParams[3];
 int nAtoms;
 int pGrid[3];
 int* atomN;
 double* posX;
 double* posY;
 double* posZ;
 double* pValue;
}tag_Models;

tag_Models chgParser(char* fname); //read orignial charge file
void saveCube(tag_Models input, char* fname); //write new charge file on the same format

main(int argc, char *argv[]){
 int i, j, k, dir, position,numlayer,mpcone,adsorbate;
 char chgFile[200];
 double dipole, q, monopole,mpclayer;
 //arguments parsing
 if(argc==8){
  sprintf(chgFile,"%s",argv[1]);
  adsorbate=atoi(argv[7]);
  if(access(chgFile,F_OK) == -1){
   printf("File does not exist.\n");
   return 0;
  }
 }

 else{
  printf("Usage: ./mdipc chgden.cube dir[x:1|y:2|z:3] position(grid#) mpclayer(bohr) tot#layer mpcone(0||1) adsorbate# \n");
  return 0;
 }
 dir=atoi(argv[2]);
 position=atoi(argv[3]);
 mpclayer=atof(argv[4]);
 numlayer=atoi(argv[5]);
 mpcone=atoi(argv[6]);

 tag_Models baseModel;
 baseModel=chgParser(chgFile); 
 monopole=0;
 for(i=0;i<baseModel.pGrid[0];i++){
   for(j=0;j<baseModel.pGrid[1];j++){
     for(k=0;k<baseModel.pGrid[2];k++){
       monopole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]];
     }
   }
 } //calculating monopole
 printf("############WARNING############### \n");
 printf("if your solute is on the same point of grid vertex, it can make problems, you should make sure of it \n");
 printf("iniMonopole(gridsum): %f\n", monopole*baseModel.cellParams[0]*baseModel.cellParams[1]*baseModel.cellParams[2]/baseModel.pGrid[0]/baseModel.pGrid[1]/baseModel.pGrid[2]);
 
 //q = monopole/baseModel.nAtoms;  
 q = monopole/(baseModel.nAtoms - adsorbate);

 if (mpcone==1){
 q *= numlayer;
 printf("monopoles are localized to the %f layer \n", mpclayer);
 printf("each ATOM has %f (e) on the %f layer\n", q*baseModel.cellParams[0]*baseModel.cellParams[1]*baseModel.cellParams[2]/baseModel.pGrid[0]/baseModel.pGrid[1]/baseModel.pGrid[2],mpclayer);//jay
 }
 else{
 printf("monopoles are localized to the all layer \n");
 printf("each ATOM has %f (e) on the all layer\n", q*baseModel.cellParams[0]*baseModel.cellParams[1]*baseModel.cellParams[2]/baseModel.pGrid[0]/baseModel.pGrid[1]/baseModel.pGrid[2]);//jay
 } 

 for(i=0;i<baseModel.nAtoms;i++){ //subtracting the monopole in the atoms' center but cannot sure center is maintained
   double px, py, pz, xd, yd, zd, x, y, z, c000, c001, c010, c100, c101, c011, c110, c111;
   x = baseModel.posX[i];
   y = baseModel.posY[i];
   z = baseModel.posZ[i];  
   //printf("x y z (in bohr unit) : %f %f %f \n", x, y, z);  by jay
   if(mpcone==1){  
     if(abs(z - mpclayer)<1.0){
       if(x<0){
         px=(fmod(x,baseModel.cellParams[0])+baseModel.cellParams[0])/(baseModel.cellParams[0]/(double)(baseModel.pGrid[0]));
       }else{
         px=fmod(x,baseModel.cellParams[0])/(baseModel.cellParams[0]/(double)(baseModel.pGrid[0]));
       }
       if(y<0){
         py=(fmod(y,baseModel.cellParams[1])+baseModel.cellParams[1])/(baseModel.cellParams[1]/(double)(baseModel.pGrid[1]));
       }else{
         py=fmod(y,baseModel.cellParams[1])/(baseModel.cellParams[1]/(double)(baseModel.pGrid[1]));
       }
       if(z<0){
         pz=(fmod(z,baseModel.cellParams[2])+baseModel.cellParams[2])/(baseModel.cellParams[2]/(double)(baseModel.pGrid[2]));
       }else{
         pz=fmod(z,baseModel.cellParams[2])/(baseModel.cellParams[2]/(double)(baseModel.pGrid[2]));
       }
       
       //printf("px py pz (grid position) : %f %f %f \n", px, py, pz); // this is grid point by jay  
       
       xd=(double)(px-(int)px);
       yd=(double)(py-(int)py);
       zd=(double)(pz-(int)pz);
       
       c000=(1-xd)*(1-yd)*(1-zd)*-q;
       c100=xd*(1-yd)*(1-zd)*-q;
       c010=(1-xd)*yd*(1-zd)*-q;
       c110=xd*yd*(1-zd)*-q;
       c001=(1-xd)*(1-yd)*zd*-q;
       c101=xd*(1-yd)*zd*-q;
       c011=(1-xd)*yd*zd*-q;
       c111=xd*yd*zd*-q;
       
       baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c000;
       baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c100;
       baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c010;
       baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c110;
       baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c001;
       baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c101;
       baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c011;
       baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c111;
     } //else is maintained
   } 
   else{
     if(x<0){
       px=(fmod(x,baseModel.cellParams[0])+baseModel.cellParams[0])/(baseModel.cellParams[0]/(double)(baseModel.pGrid[0]));
     }else{
       px=fmod(x,baseModel.cellParams[0])/(baseModel.cellParams[0]/(double)(baseModel.pGrid[0]));
     }
     if(y<0){
       py=(fmod(y,baseModel.cellParams[1])+baseModel.cellParams[1])/(baseModel.cellParams[1]/(double)(baseModel.pGrid[1]));
     }else{
       py=fmod(y,baseModel.cellParams[1])/(baseModel.cellParams[1]/(double)(baseModel.pGrid[1]));
     }
     if(z<0){
       pz=(fmod(z,baseModel.cellParams[2])+baseModel.cellParams[2])/(baseModel.cellParams[2]/(double)(baseModel.pGrid[2]));
     }else{
       pz=fmod(z,baseModel.cellParams[2])/(baseModel.cellParams[2]/(double)(baseModel.pGrid[2]));
     }
     
     //printf("px py pz (grid position) : %f %f %f \n", px, py, pz); // this is grid point by jay  
     
     xd=(double)(px-(int)px);
     yd=(double)(py-(int)py);
     zd=(double)(pz-(int)pz);
     
     c000=(1-xd)*(1-yd)*(1-zd)*-q;
     c100=xd*(1-yd)*(1-zd)*-q;
     c010=(1-xd)*yd*(1-zd)*-q;
     c110=xd*yd*(1-zd)*-q;
     c001=(1-xd)*(1-yd)*zd*-q;
     c101=xd*(1-yd)*zd*-q;
     c011=(1-xd)*yd*zd*-q;
     c111=xd*yd*zd*-q;
     
     baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c000;
     baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c100;
     baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c010;
     baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c110;
     baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c001;
     baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c101;
     baseModel.pValue[((int)pz)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c011;
     baseModel.pValue[((int)pz+1)%baseModel.pGrid[2]+(((int)py+1)%baseModel.pGrid[1])*baseModel.pGrid[2]+(((int)px+1)%baseModel.pGrid[0])*baseModel.pGrid[2]*baseModel.pGrid[1]]+=c111;
   }
 }

 //saveCube(baseModel, "mpc.cube"); // save new charge file on the same grid format

//monopole correction end //jay
//dipole correction start //jay
 if(dir==3){
   dipole=0;
   for(i=0;i<baseModel.pGrid[0];i++){
     for(j=0;j<baseModel.pGrid[1];j++){
       for(k=0;k<baseModel.pGrid[2];k++){
         if(k < position) {
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*k;
         }else{
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*(k-baseModel.pGrid[2]);
         }
       }
     }
   }
   for(i=0;i<baseModel.pGrid[0];i++){
     for(j=0;j<baseModel.pGrid[1];j++){ 
        baseModel.pValue[position+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]=dipole/baseModel.pGrid[0]/baseModel.pGrid[1];
        baseModel.pValue[(position+1)+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]=-1*dipole/baseModel.pGrid[0]/baseModel.pGrid[1];
     }
   }
 }
 if(dir==2){
   dipole=0;
   for(i=0;i<baseModel.pGrid[0];i++){
     for(k=0;j<baseModel.pGrid[2];k++){
       for(j=0;j<baseModel.pGrid[1];j++){
         if(j < position) {
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*j;
         }else{
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*(j-baseModel.pGrid[1]);
         }
       }
     }
   }
   for(i=0;i<baseModel.pGrid[0];i++){
     for(k=0;k<baseModel.pGrid[2];k++){ 
        baseModel.pValue[k+position*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]=dipole/baseModel.pGrid[0]/baseModel.pGrid[2];
        baseModel.pValue[k+(position+1)*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]=-1*dipole/baseModel.pGrid[0]/baseModel.pGrid[2];
     }
   }
 }
 if(dir==1){
   dipole=0;
   for(j=0;j<baseModel.pGrid[1];j++){
     for(k=0;k<baseModel.pGrid[2];k++){
       for(i=0;i<baseModel.pGrid[0];i++){
         if(i < position) {
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*i;
         }else{
           dipole += baseModel.pValue[k+j*baseModel.pGrid[2]+i*baseModel.pGrid[2]*baseModel.pGrid[1]]*(i-baseModel.pGrid[0]);
         }
       }
     }
   }
   for(j=0;j<baseModel.pGrid[1];j++){
     for(k=0;k<baseModel.pGrid[2];k++){ 
        baseModel.pValue[k+j*baseModel.pGrid[2]+position*baseModel.pGrid[2]*baseModel.pGrid[1]]=dipole/baseModel.pGrid[1]/baseModel.pGrid[2];
        baseModel.pValue[k+j*baseModel.pGrid[2]+(position+1)*baseModel.pGrid[2]*baseModel.pGrid[1]]=-1*dipole/baseModel.pGrid[1]/baseModel.pGrid[2];
     }
   }
  }
 //dipole *= (baseModel.cellParams[0]*baseModel.cellParams[1]*baseModel.cellParams[2]/baseModel.pGrid[0]/baseModel.pGrid[1]/baseModel.pGrid[2])*baseModel.cellParams[2]/baseModel.pGrid[2]*0.529177;
 //printf("system dipole moment: %lf eA, %lf Debye\n",dipole, dipole/0.20819434);
 saveCube(baseModel, "mdipc.cube");  // save new charge file on the same grid format
}//main END

tag_Models chgParser(char* fname){ // charge density file parsing using atomic units
 FILE* fp;
 char str[2048], *str_ptr;
 int flag=0, nline=0,cnt=0,nAtoms=0;
 tag_Models output;

 fp=fopen(fname, "r");
 output.nAtoms=0;
 output.cellParams[0]=output.cellParams[1]=output.cellParams[2]=(double)0; 
 
 while(fgets(str,sizeof(str),fp)!=NULL){
  int i, j, *temp;
  double a,b,c;
  nline++;
  
  if(nline==3){
   sscanf(str,"%d %*f %*f %*f",&output.nAtoms);
   output.atomN = (int *) malloc (output.nAtoms*sizeof(int));
   output.posX = (double *) malloc (output.nAtoms*sizeof(double));
   output.posY = (double *) malloc (output.nAtoms*sizeof(double));
   output.posZ = (double *) malloc (output.nAtoms*sizeof(double));
  }

  if(nline==4){
   sscanf(str,"%d %lf %*f %*f",&output.pGrid[0], &output.cellParams[0]);
   output.cellParams[0]=output.pGrid[0]*output.cellParams[0];
  }

  if(nline==5){
   sscanf(str,"%d %*f %lf %*f",&output.pGrid[1], &output.cellParams[1]);
   output.cellParams[1]=output.pGrid[1]*output.cellParams[1];
  }

  if(nline==6){
   sscanf(str,"%d %*f %*f %lf",&output.pGrid[2], &output.cellParams[2]);
   output.cellParams[2]=output.pGrid[2]*output.cellParams[2];
  }

  if(nline>=7 && nline<7+output.nAtoms){
    sscanf(str,"%d %*f %lf %lf %lf",&output.atomN[nline-7],&output.posX[nline-7],&output.posY[nline-7],&output.posZ[nline-7]);
  }

  if(nline==output.nAtoms+6){
   printf("### Cell parameters(Bohr): %f %f %f\n", output.cellParams[0], output.cellParams[1], output.cellParams[2]);
   printf("### Number of Atoms: %d\n", output.nAtoms);
   printf("### Grid Dimension: %d %d %d\n", output.pGrid[0], output.pGrid[1], output.pGrid[2]);
   output.pValue=(double *)malloc(output.pGrid[0]*output.pGrid[1]*output.pGrid[2]*sizeof(double));
  }

  if(nline>=output.nAtoms+7 && cnt<output.pGrid[0]*output.pGrid[1]*output.pGrid[2]){
   str_ptr=strtok(str," ");
   for(;str_ptr!=NULL;cnt++){
     sscanf(str_ptr,"%lf",&output.pValue[cnt]);
    str_ptr=strtok(NULL," ");
   }
  }
   
 }//while end
 return output;
}

void saveCube(tag_Models input, char* fname){
  FILE* fp;
  int i, j, k, cnt;
  fp = fopen(fname,"w");

  fprintf(fp," Cubefile created from chg2pot\n");
  fprintf(fp," ES potential, lattice unit Bohr, grid unit Ry\n");
  fprintf(fp,"% 5d    0.000000    0.000000    0.000000\n",input.nAtoms);
  fprintf(fp,"% 5d% 12.6lf    0.000000    0.000000\n",input.pGrid[0],input.cellParams[0]/input.pGrid[0]);
  fprintf(fp,"% 5d    0.000000% 12.6lf    0.000000\n",input.pGrid[1],input.cellParams[1]/input.pGrid[1]);
  fprintf(fp,"% 5d    0.000000    0.000000% 12.6lf\n",input.pGrid[2],input.cellParams[2]/input.pGrid[2]);
  for(i=0;i<input.nAtoms;i++){
    fprintf(fp,"% 5d% 12.6lf% 12.6lf% 12.6lf% 12.6lf\n",input.atomN[i],(double)input.atomN[i],input.posX[i],input.posY[i],input.posZ[i]);
  }
  cnt=0;
  for(i=0;i<input.pGrid[0];i++){
    for(j=0;j<input.pGrid[1];j++){
      for(k=0;k<input.pGrid[2];k++){
         fprintf(fp,"% 13.5lE",(input.pValue[k+j*input.pGrid[2]+i*input.pGrid[2]*input.pGrid[1]]));
         if(cnt%6 == 5) fprintf(fp,"\n");
         cnt++;
      }
    }
  }
  fclose(fp);
  printf("### Monopole & dipole corrected : %s\n",fname);
}


