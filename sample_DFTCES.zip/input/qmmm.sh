#!/bin/bash

# Global variables
NP="28" #number of cores for your processor 
QMMMMAXSTEP="?" # no of QMMM loop
SUPERCELL=(9 8 1) # supercell factor x, y, z / compared to the DFT cell
DIPOLEDIR="3" # dipole correction direction x=1 y=2 z=3
DIPOLEPOS="0.80" # dipole correction fractional position along DIPOLEDIR
LAMMPS="/Your/lammps/binary"
QEPW="/Your/qepw/binary"
QEPP="/Your/qepp/binary"

CUBESUB="Your/cube_sub"
CUBEADD="Your/cube_add"
CUBEMULTI="Your/cube_multi"
MDIPC="Your/mdipc"
CHG2POT="Your/chg2pot"

LAMMPSIN="base.in.lammps"
QMIN="base.pw.in"
QMIN2="base.pp.in"

LAMMPSRESTART="Ag111_4sl_t3p0M.emd.500000.restart"
MDEQUIL="1000" 
MDAVERAGE="1000" 

TOTCHG="0.0" # (-):put more electrons, for QM cal , should be "0.0" for PZC
mpclayer="13.5" #bohr unit mpc layer # referring mdipc.c 
totlayer="4"  # referring mdipc.c 
mpcone="1"    # referring mdipc.c 
adsorbate="0" # referring mdipc.c
initialqm=0 #initial qm exist yes=1 no=0
finalmm=0 #final md do or not yes=1 no=0
qmmmstep=0

for ((qmmmstep=$qmmmstep; qmmmstep<$QMMMMAXSTEP; qmmmstep++))
do
  echo "######### Starting $qmmmstep QMMM step #########"$'\n'
  # Make saving directory
  mkdir qm_$qmmmstep
  mkdir mm_$qmmmstep

  # Make pw.in based on $QMIN 
  if [ $qmmmstep -gt 0 ]; then
    sed -i "s/.*\&CONTROL.*/&\ndft_ces = .true./" pw.in
    sed -i "s/.*\&CONTROL.*/&\nrho_ces = '.\/empty.cube'/" pw.in
    sed -i "s/.*\&CONTROL.*/&\nrho_ces_ion = '.\/MDrho.cube'/" pw.in
    sed -i "s/.*\&CONTROL.*/&\nrho_ces_rep = '.\/empty.cube'/" pw.in
    sed -i "s/.*\&SYSTEM.*/&\ntot_charge = $TOTCHG/" pw.in
    cp ./mm_$((qmmmstep-1))/MDrho.cube ./
    cp ./mm_$((qmmmstep-1))/empty.cube ./
  fi
 
  # Run QM calculation
  finished=""
  echo "### QM calculation starting at $qmmmstep QMMM iterations"$'\n'
  if [ $initialqm -eq 0 ]; then
   mpirun -np $NP $QEPW -inp pw.in > pw.out
     finished=`grep "JOB DONE" pw.out`
     if [ "$finished" != "" ]; then 
       echo "### QM calculation done"$'\n'
       break
     else
       echo "### QM calculation aborted, check output file"$'\n'
       exit
     fi
  else
   echo "###QM calculation in $qmmmstep QMMM iterations already exists"
   break
  fi
  cp pw.in pw.out v_saw.cube v_md.cube v_md_ion.cube v_hartree.cube qm_$qmmmstep
  
  # Generating QM solute potential and backup QM results
  echo "### Generating QM potential .. "$'\n'
  # makeing pp.in
    cp $QMIN2 pp.pot.in
    cp $QMIN2 pp.rho.in
    sed -i "s/.*plot_num.*/plot_num = 0/" pp.rho.in
    sed -i "s/.*fileout.*/fileout = 'val.rho.cube'/" pp.rho.in
  #
  if [ $initialqm -eq 0 ]; then
   if [ $qmmmstep -eq 0 ]; then
     mpirun -np $NP $QEPP -inp pp.pot.in > pp.pot.out
     ppdone1=`ls solute.cube`
     mpirun -np $NP $QEPP -inp pp.rho.in > pp.rho.out
     ppdone2=`ls val.rho.cube`
     if [ "$ppdone1" == "" ] || ["$ppdone2" == "" ] ; then
       echo "### QM post processing failed, aborting whole qmmm loop"$'\n'
       exit
     else
       cp val.rho.cube refval.rho.cube 
       $CUBEADD solute.cube qm_0/v_saw.cube
       cp add.cube solute.cube
       cp pp.pot.in pp.rho.in pp.pot.out pp.rho.out solute.cube refval.rho.cube qm_$qmmmstep
     fi
   else
     mpirun -np $NP $QEPP -inp pp.pot.in > pp.pot.out
     ppdone1=`ls solute.cube`
     mpirun -np $NP $QEPP -inp pp.rho.in > pp.rho.out
     ppdone2=`ls val.rho.cube`
     if [ "$ppdone1" == "" ] || ["$ppdone2" == "" ] ; then
       echo "### QM post processing failed, aborting whole qmmm loop"$'\n'
       exit
     else
       cp solute.cube v_b+h.cube
       $CUBESUB val.rho.cube qm_0/refval.rho.cube
       dipolegrid=`awk -v dir=$DIPOLEDIR -v pos=$DIPOLEPOS '{if(NR==(dir+3)) printf "%d", $1*pos}' solute.cube`
       echo "### dipole correction has been applied: dir=$DIPOLEDIR, grid=$dipolegrid"
       $MDIPC subtracted.cube $DIPOLEDIR $dipolegrid $mpclayer $totlayer $mpcone $adsorbate
       $CHG2POT mdipc.cube $DIPOLEDIR
       $CUBEMULTI pot.cube 2  #to set Ha to ryd
       $CUBEADD multiplied.cube qm_0/solute.cube
       cp add.cube solute.cube
       cp pp.pot.in pp.rho.in pp.pot.out pp.rho.out solute.cube val.rho.cube v_b+h.cube qm_$qmmmstep
       rm -f val.rho.cube
     fi
   fi
  fi
  initialqm=0

  ##########################################
  if [ $((qmmmstep+1)) -eq $QMMMMAXSTEP ] && [ $finalmm -eq 0 ]; then
  echo "### MD at $qmmmstep step is not calculated"
  exit
  fi
  ##########################################

  # Making LAMMPS INPUT : modifying restart, geometry
  cp $LAMMPSIN in.lammps
  sed -i "s/.*read_restart.*/read_restart $LAMMPSRESTART/" in.lammps
  cp ./qm_$qmmmstep/solute.cube ./

  # RUN LAMMPS calculation
  echo "### Running LAMMPS(emxext) for equilibration $qmmmstep QMMM iterations"$'\n'
  sed -i "s/.*run.*/run\t\t$MDEQUIL/" in.lammps
  mpirun -np $NP $LAMMPS -in in.lammps > lammps.equil.out 
  cp in.lammps in.lammps.equil
  LAMMPSRESTART=`ls -lrt *.restart | tail -n 1 | awk '{print $9}'`
  sed -i "s/.*read_restart.*/read_restart $LAMMPSRESTART/" in.lammps

  echo "### Running LAMMPS(emdext) for averaging solvent charge density $qmmmstep QMMM iterations"$'\n'
  sed -i "s/.*run.*/run\t\t$MDAVERAGE/" in.lammps
  mpirun -np $NP $LAMMPS -in in.lammps > lammps.average.out
  cp in.lammps in.lammps.average
  LAMMPSRESTART=`ls -lrt *.restart | tail -n 1 | awk '{print $9}'`
  lammpsout=`ls -lrt *.out | tail -n 1 | awk '{print $9}'`
  finished=`grep "Please see the log.cite" $lammpsout`
  if [ "$finished" != "" ]; then 
    echo "### MM calculation done"$'\n'
  else
    echo "### MM calculation aborted, check output file"$'\n'
    exit
  fi
  rm -f log.lammps
  $CUBEMULTI MDrho.cube 0
  cp multiplied.cube empty.cube
  cp data.lammps in.lammps.* empty.cube MDrho.cube *.lammpstrj $LAMMPSRESTART lammps.*.out mm_$qmmmstep
done # qmmm loop
